package com.delegateapp;

interface Allocator
{
	void taskAllocation(String user);

}
