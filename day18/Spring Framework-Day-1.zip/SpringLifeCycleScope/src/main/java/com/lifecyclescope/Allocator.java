package com.lifecyclescope;

interface Allocator
{
	void taskAllocation(String user);

}
