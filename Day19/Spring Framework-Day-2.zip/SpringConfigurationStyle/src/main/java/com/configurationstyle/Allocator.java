package com.configurationstyle;

interface Allocator
{
	void taskAllocation(String user);

}
