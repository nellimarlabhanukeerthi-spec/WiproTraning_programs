package com.configurationstyle;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages="com.configurationstyle")
public class AnnotationBasedConfig {
	
}
