package com.dependencyinjection;

interface Allocator
{
	void taskAllocation(String user);

}
