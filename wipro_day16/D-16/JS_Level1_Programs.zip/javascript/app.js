alert("Calling app.js file content");

let age = 25;  // Number
const myName = "Niti"; // String
var isTrue = true;  // Boolean

console.log(typeof(age));

console.log(typeof(myName));

// conversion 

let score = "100";
let toIntScore = Number(score);

// use case :--  user input for calculation ( to validate and convert user input for calculations);

let sum = 5%4;
console.log("The value of sum is :" + sum);
                                                                                                                                                                                                    

//Activity :--  Validate User Registration Data Types

/*Suppose you are creating a user registration form for a website  , the form should capture 
-UserName
- Age
-isSubscribe and you need to check whether the provided data matches the expected types */